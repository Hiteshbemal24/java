package dsa;

public class Knapsack1 {
	
	class ItemValue{
		int weight;
		int value;
		
		ItemValue(int value, int weight){
			this.value = value;
			this.weight = weight;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
